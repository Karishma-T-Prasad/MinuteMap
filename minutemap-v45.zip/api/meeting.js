import { db } from "hatchable";

export const access = "user";
export const methods = ["GET", "DELETE"];

export default async function (req, res) {
  const userId = req.user.id;
  const id = String(req.query?.id || "").trim();
  if (!id) return res.status(400).json({ error: "Meeting ID is required." });

  if (req.method === "DELETE") {
    const removed = await db.query("DELETE FROM meetings WHERE id = $1 AND user_id = $2 RETURNING id", [id, userId]);
    if (!removed.rowCount) return res.status(404).json({ error: "Meeting not found." });
    return res.json({ deleted: true });
  }

  const meetingResult = await db.query("SELECT id, meeting_date, topic, summary, raw_notes, decisions, key_dates, risks, unresolved, missing_information, created_at FROM meetings WHERE id = $1 AND user_id = $2", [id, userId]);
  if (!meetingResult.rows.length) return res.status(404).json({ error: "Meeting not found." });
  const actionResult = await db.query("SELECT id, owner, owner_email, task, deadline, deadline_text, status, reminder_enabled, reminder_days_before, created_at FROM action_items WHERE meeting_id = $1 AND user_id = $2 ORDER BY deadline NULLS LAST, created_at", [id, userId]);
  res.json({ meeting: meetingResult.rows[0], actions: actionResult.rows });
}