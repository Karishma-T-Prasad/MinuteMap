import { db } from "hatchable";
import { sendMinuteMapEmail } from "../lib/mailer.js";

export const access = "user";
export const methods = ["POST"];

function clean(value, max = 1500) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function emails(value) {
  return [...new Set(String(value || "").replace(/\r?\n/g, ",").split(/[,;]+/).map(x => x.trim().toLowerCase()).filter(x => /^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(x)))];
}
function escapeHtml(value) {
  return String(value || "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
}
function todayIndia() {
  return new Date(Date.now() + 330 * 60 * 1000).toISOString().slice(0, 10);
}

export default async function (req, res) {
  const actions = Array.isArray(req.body?.result?.action_items) ? req.body.result.action_items.slice(0, 100) : [];
  if (!actions.length) return res.json({ checked: 0, due_today: 0, sent: 0, failed: 0 });
  const userId = req.user.id;
  const today = todayIndia();
  const settingResult = await db.query("SELECT reminder_email, reminders_enabled FROM user_settings WHERE user_id = $1", [userId]);
  const settings = settingResult.rows[0] || {};
  if (settings.reminders_enabled === false) return res.json({ checked: actions.length, due_today: 0, sent: 0, failed: 0, disabled: true });

  const recipientsDefault = [
    ...emails(settings.reminder_email),
    ...emails(req.body?.default_email),
    ...emails(req.user?.email)
  ];
  const defaultRecipients = [...new Set(recipientsDefault)];
  let dueToday = 0, sent = 0, failed = 0;
  const processed = new Set();

  for (const action of actions) {
    const task = clean(action?.task);
    const deadline = clean(action?.deadline, 20).slice(0, 10);
    const status = clean(action?.status, 30);
    if (!task || deadline !== today || status === "Done") continue;
    dueToday++;
    const recipients = [...new Set([...emails(action?.owner_email), ...defaultRecipients])];
    for (const recipient of recipients) {
      const key = task.toLowerCase() + "|" + deadline + "|" + recipient;
      if (processed.has(key)) continue;
      processed.add(key);
      const existing = await db.query(
        "SELECT id FROM notification_logs WHERE user_id = $1 AND notification_type = 'deadline_due_today' AND lower(task) = lower($2) AND deadline = $3 AND recipient = $4 AND status = 'sent' AND created_at > now() - interval '5 minutes' LIMIT 1",
        [userId, task, deadline, recipient]
      );
      if (existing.rows.length) continue;

      const topic = clean(req.body?.result?.topic, 300) || "Meeting";
      const subject = "MinuteMap: action due today — " + task.slice(0, 100);
      const text = "MinuteMap deadline alert\n\nTask: " + task + "\nMeeting: " + topic + "\nDeadline: " + deadline + "\nStatus: " + (status || "Pending") + "\n\nThis task was identified in your meeting notes and is due today.";
      const html = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#20283b"><p style="color:#087eaf;font-weight:bold">MinuteMap · Deadline alert</p><h2>Action due today</h2><p><b>Task:</b> ' + escapeHtml(task) + '</p><p><b>Meeting:</b> ' + escapeHtml(topic) + '</p><p><b>Deadline:</b> ' + escapeHtml(deadline) + '</p><p><b>Status:</b> ' + escapeHtml(status || "Pending") + '</p><p>This action was identified when you analysed your meeting notes.</p></div>';
      try {
        await sendMinuteMapEmail({ to: recipient, subject, text, html });
        await db.query("INSERT INTO notification_logs (user_id, notification_type, task, topic, deadline, recipient, status, sent_at) VALUES ($1, 'deadline_due_today', $2, $3, $4, $5, 'sent', now())", [userId, task, topic, deadline, recipient]);
        sent++;
      } catch (error) {
        const message = String(error?.message || "Email delivery failed").slice(0, 500);
        await db.query("INSERT INTO notification_logs (user_id, notification_type, task, topic, deadline, recipient, status, error) VALUES ($1, 'deadline_due_today', $2, $3, $4, $5, 'failed', $6)", [userId, task, topic, deadline, recipient, message]);
        console.error("MinuteMap due-today notification failed", { task, recipient, message });
        failed++;
      }
    }
  }
  res.json({ checked: actions.length, due_today: dueToday, sent, failed });
}