import { db } from "hatchable";
import { sendMinuteMapEmail } from "../lib/mailer.js";

export const access = "user";
export const methods = ["POST"];

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
}

export default async function (req, res) {
  const settingsResult = await db.query("SELECT reminder_email FROM user_settings WHERE user_id = $1", [req.user.id]);
  const rawRecipient = typeof req.body?.recipient === "string" && req.body.recipient.trim() ? req.body.recipient : (settingsResult.rows[0]?.reminder_email || req.user?.email || "");
  const recipients = [...new Set(String(rawRecipient).replace(/\r?\n/g, ",").split(/[,;]+/).map(x => x.trim().toLowerCase()).filter(Boolean))];
  if (!recipients.length) return res.status(400).json({ error: "Add at least one reminder recipient email address." });
  if (recipients.some(address => !/^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(address))) return res.status(400).json({ error: "Enter valid email addresses separated by commas or new lines." });
  const recipient = recipients.join(", ");
  await db.query("INSERT INTO user_settings (user_id, reminder_email) VALUES ($1, $2) ON CONFLICT (user_id) DO NOTHING", [req.user.id, recipient]);
  const claim = await db.query(
    "UPDATE user_settings SET last_test_email_at = now() WHERE user_id = $1 AND (last_test_email_at IS NULL OR last_test_email_at < now() - interval '10 minutes') RETURNING user_id",
    [req.user.id]
  );
  if (!claim.rows.length) return res.status(429).json({ error: "A test email was sent recently. Please wait 10 minutes before trying again." });

  const subject = "MinuteMap — your test reminder is working";
  const text = "This is a test email from MinuteMap. Your reminder email connection is ready to test. You can now save tasks and configure deadline reminders.";
  const html = "<div style=\"font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#24213a\"><p style=\"color:#7357d9;font-weight:bold\">MinuteMap</p><h2>Your reminder email test</h2><p>This is a test email from MinuteMap.</p><p>Your reminder email connection is ready to test. Save tasks and configure deadline reminders in your workspace.</p></div>";
  try {
    const result = await sendMinuteMapEmail({ to: recipient, subject, text, html });
    res.json({ sent: true, recipient, sender: result.sender });
  } catch (error) {
    console.error("MinuteMap test email failed", String(error?.message || error));
    res.status(502).json({ error: "Email could not be sent. Check Gmail connection in project Setup or email service restrictions, then try again." });
  }
}