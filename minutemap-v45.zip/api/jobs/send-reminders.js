import { db } from "hatchable";
import { sendMinuteMapEmail } from "../../lib/mailer.js";

export const access = "scheduler";
export const methods = ["POST"];

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
}

export default async function (req, res) {
  const candidates = await db.query(
    "SELECT a.id, a.user_id, a.owner, a.owner_email, a.task, a.deadline, a.status, a.reminder_days_before, m.topic, concat_ws(', ', NULLIF(a.owner_email, ''), NULLIF(s.reminder_email, '')) AS recipient FROM action_items a JOIN meetings m ON m.id = a.meeting_id LEFT JOIN user_settings s ON s.user_id = a.user_id WHERE a.reminder_enabled = true AND a.status <> 'Done' AND a.deadline IS NOT NULL AND a.deadline = (CURRENT_DATE + a.reminder_days_before) AND COALESCE(s.reminders_enabled, true) = true AND COALESCE(NULLIF(a.owner_email, ''), NULLIF(s.reminder_email, '')) IS NOT NULL AND NOT EXISTS (SELECT 1 FROM reminder_logs l WHERE l.action_id = a.id AND l.reminder_for_date = a.deadline AND l.status = 'sent') AND NOT EXISTS (SELECT 1 FROM notification_logs n WHERE n.user_id = a.user_id AND n.notification_type = 'deadline_due_today' AND n.status = 'sent' AND lower(n.task) = lower(a.task) AND n.deadline = a.deadline AND n.created_at > now() - interval '24 hours') ORDER BY a.deadline ASC LIMIT 10"
  );

  let sent = 0, skipped = 0, failed = 0;
  for (const item of candidates.rows) {
    const claim = await db.query(
      "INSERT INTO reminder_logs (action_id, user_id, reminder_for_date, status) VALUES ($1, $2, $3, 'processing') ON CONFLICT (action_id, reminder_for_date) DO UPDATE SET status = 'processing', error = NULL WHERE reminder_logs.status = 'failed' RETURNING id",
      [item.id, item.user_id, item.deadline]
    );
    if (!claim.rows.length) { skipped++; continue; }

    const due = String(item.deadline).slice(0, 10);
    const subject = "MinuteMap reminder (" + item.status + "): " + item.task.slice(0, 100) + " — due " + due;
    const plain = "MinuteMap deadline reminder\n\nTask: " + item.task + "\nMeeting: " + item.topic + "\nOwner: " + (item.owner || "Unassigned") + "\nDeadline: " + due + "\nStatus: " + item.status + "\n\nOpen MinuteMap to update the task status.";
    const html = "<div style=\"font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#222\"><p style=\"color:#7357d9;font-weight:bold\">MinuteMap · Deadline reminder</p><h2>One of your action items is coming due</h2><p><b>Task:</b> " + escapeHtml(item.task) + "</p><p><b>Meeting:</b> " + escapeHtml(item.topic) + "</p><p><b>Owner:</b> " + escapeHtml(item.owner || "Unassigned") + "</p><p><b>Deadline:</b> " + escapeHtml(due) + "</p><p><b>Status:</b> " + escapeHtml(item.status) + "</p><p>Open MinuteMap to review and update the task.</p></div>";
    try {
      await sendMinuteMapEmail({ to: item.recipient, subject, text: plain, html });
      await db.query("UPDATE reminder_logs SET status = 'sent', sent_at = now(), error = NULL WHERE id = $1", [claim.rows[0].id]);
      sent++;
    } catch (err) {
      const message = String(err?.message || "Email delivery failed").slice(0, 500);
      await db.query("UPDATE reminder_logs SET status = 'failed', error = $2 WHERE id = $1", [claim.rows[0].id, message]);
      console.error("Reminder send failed", { actionId: item.id, message });
      failed++;
    }
  }
  res.json({ ok: true, checked: candidates.rows.length, sent, skipped, failed, note: "Batches are capped at 10 sends per run." });
}