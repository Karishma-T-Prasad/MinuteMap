import { db } from "hatchable";

export const access = "user";
export const methods = ["GET", "PUT"];

export default async function (req, res) {
  const userId = req.user.id;
  if (req.method === "GET") {
    const result = await db.query("SELECT reminder_email, default_reminder_days, reminders_enabled FROM user_settings WHERE user_id = $1", [userId]);
    return res.json({ settings: result.rows[0] || { reminder_email: req.user.email || "", default_reminder_days: 1, reminders_enabled: true } });
  }
  const email = typeof req.body?.reminder_email === "string" ? req.body.reminder_email.replace(/\r?\n/g, ",").split(/[,;]+/).map(x => x.trim().toLowerCase()).filter(Boolean).filter((x, i, a) => a.indexOf(x) === i).join(", ").slice(0, 2000) : "";
  const days = Number(req.body?.default_reminder_days);
  const reminderDays = Number.isInteger(days) ? Math.min(30, Math.max(0, days)) : 1;
  if (email && email.split(", ").some(address => !/^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(address))) return res.status(400).json({ error: "Enter valid email addresses separated by commas or new lines." });
  const enabled = req.body?.reminders_enabled !== false;
  await db.query(
    "INSERT INTO user_settings (user_id, reminder_email, default_reminder_days, reminders_enabled, updated_at) VALUES ($1, $2, $3, $4, now()) ON CONFLICT (user_id) DO UPDATE SET reminder_email = EXCLUDED.reminder_email, default_reminder_days = EXCLUDED.default_reminder_days, reminders_enabled = EXCLUDED.reminders_enabled, updated_at = now()",
    [userId, email, reminderDays, enabled]
  );
  res.json({ saved: true, settings: { reminder_email: email, default_reminder_days: reminderDays, reminders_enabled: enabled } });
}