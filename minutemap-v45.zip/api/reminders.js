import { db } from "hatchable";

export const access = "user";
export const methods = ["GET"];

export default async function (req, res) {
  const { rows } = await db.query(
    "SELECT id, reminder_for_date, status, sent_at, error, task, owner, topic, notification_type, recipient, old_status, new_status, created_at FROM (SELECT l.id, l.reminder_for_date, l.status, l.sent_at, l.error, a.task, a.owner, m.topic, 'deadline_reminder'::text AS notification_type, NULL::text AS recipient, NULL::text AS old_status, NULL::text AS new_status, l.created_at FROM reminder_logs l JOIN action_items a ON a.id = l.action_id JOIN meetings m ON m.id = a.meeting_id WHERE l.user_id = $1 UNION ALL SELECT n.id, COALESCE(n.deadline, n.created_at::date) AS reminder_for_date, n.status, n.sent_at, n.error, n.task, COALESCE(a.owner, '') AS owner, n.topic, n.notification_type, n.recipient, n.old_status, n.new_status, n.created_at FROM notification_logs n LEFT JOIN action_items a ON a.id = n.action_id WHERE n.user_id = $1) activity ORDER BY created_at DESC LIMIT 50",
    [req.user.id]
  );
  res.json({ reminders: rows });
}