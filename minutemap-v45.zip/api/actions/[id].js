import { db } from "hatchable";
import { sendMinuteMapEmail } from "../../lib/mailer.js";

export const access = "user";
export const methods = ["PUT"];

function clean(v, max = 1500) { return typeof v === "string" ? v.trim().slice(0, max) : ""; }
function emails(value) {
  return [...new Set(String(value || "").replace(/\r?\n/g, ",").split(/[,;]+/).map(x => x.trim().toLowerCase()).filter(x => /^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(x)))];
}
function escapeHtml(value) {
  return String(value || "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
}

export default async function (req, res) {
  const id = String(req.params?.id || "").trim();
  const body = req.body || {};
  const status = clean(body.status, 30);
  const ownerEmail = clean(body.owner_email, 2000).toLowerCase();
  const owner = clean(body.owner, 200);
  const days = Number(body.reminder_days_before);
  const reminderDays = Number.isInteger(days) ? Math.min(30, Math.max(0, days)) : 1;
  if (!id) return res.status(400).json({ error: "Action ID is required." });
  if (!["Pending", "In Progress", "Done"].includes(status)) return res.status(400).json({ error: "Invalid status." });
  if (ownerEmail && emails(ownerEmail).length !== ownerEmail.replace(/\r?\n/g, ",").split(/[,;]+/).filter(x => x.trim()).length) return res.status(400).json({ error: "Enter valid recipient email addresses separated by commas or new lines." });

  const before = await db.query(
    "SELECT a.id, a.status AS old_status, a.task, a.deadline, a.owner, a.owner_email, m.topic FROM action_items a JOIN meetings m ON m.id = a.meeting_id WHERE a.id = $1 AND a.user_id = $2",
    [id, req.user.id]
  );
  if (!before.rows.length) return res.status(404).json({ error: "Action not found." });
  const previous = before.rows[0];

  const result = await db.query(
    "UPDATE action_items SET owner = $1, owner_email = $2, status = $3, reminder_enabled = $4, reminder_days_before = $5, updated_at = now() WHERE id = $6 AND user_id = $7 RETURNING id, owner, owner_email, status, reminder_enabled, reminder_days_before",
    [owner, ownerEmail, status, body.reminder_enabled !== false, reminderDays, id, req.user.id]
  );
  const action = result.rows[0];
  let notification = { sent: 0, failed: 0 };
  if (previous.old_status !== status) {
    const settingResult = await db.query("SELECT reminder_email FROM user_settings WHERE user_id = $1", [req.user.id]);
    const recipients = [...new Set([
      ...emails(action.owner_email),
      ...emails(settingResult.rows[0]?.reminder_email),
      ...emails(req.user?.email)
    ])];
    const deadline = previous.deadline ? String(previous.deadline).slice(0, 10) : "";
    const subject = "MinuteMap status update: " + previous.task.slice(0, 100) + " — " + status;
    for (const recipient of recipients) {
      const text = "MinuteMap task status update\n\nTask: " + previous.task + "\nMeeting: " + previous.topic + "\nPrevious status: " + previous.old_status + "\nNew status: " + status + "\nDeadline: " + (deadline || "Not set") + "\n\nThis task status was updated in MinuteMap.";
      const html = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#20283b"><p style="color:#087eaf;font-weight:bold">MinuteMap · Task update</p><h2>Task status changed</h2><p><b>Task:</b> ' + escapeHtml(previous.task) + '</p><p><b>Meeting:</b> ' + escapeHtml(previous.topic) + '</p><p><b>Previous status:</b> ' + escapeHtml(previous.old_status) + '</p><p><b>New status:</b> ' + escapeHtml(status) + '</p><p><b>Deadline:</b> ' + escapeHtml(deadline || "Not set") + '</p></div>';
      try {
        await sendMinuteMapEmail({ to: recipient, subject, text, html });
        await db.query("INSERT INTO notification_logs (user_id, action_id, notification_type, task, topic, deadline, old_status, new_status, recipient, status, sent_at) VALUES ($1, $2, 'status_changed', $3, $4, $5, $6, $7, $8, 'sent', now())", [req.user.id, id, previous.task, previous.topic, previous.deadline, previous.old_status, status, recipient]);
        notification.sent++;
      } catch (error) {
        const message = String(error?.message || "Email delivery failed").slice(0, 500);
        try {
          await db.query("INSERT INTO notification_logs (user_id, action_id, notification_type, task, topic, deadline, old_status, new_status, recipient, status, error) VALUES ($1, $2, 'status_changed', $3, $4, $5, $6, $7, $8, 'failed', $9)", [req.user.id, id, previous.task, previous.topic, previous.deadline, previous.old_status, status, recipient, message]);
        } catch (logError) {
          console.error("Could not log status notification failure", String(logError?.message || logError));
        }
        console.error("MinuteMap status notification failed", { actionId: id, recipient, message });
        notification.failed++;
      }
    }
  }
  res.json({ action, notification });
}