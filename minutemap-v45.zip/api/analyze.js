import { config } from "hatchable";

export const access = "user";
export const methods = ["POST"];

const SYSTEM_PROMPT = `You are MinuteMap, a careful meeting-notes analyst and action coordinator. Extract every actionable commitment and important uncertainty from messy notes, shorthand, fragments, punctuation, and informal language. Do not invent facts.
Return ONLY labelled plain text in exactly this order:
MEETING_DATE: YYYY-MM-DD or Unknown
TOPIC: short title
SUMMARY: concise summary including the overall goal and most urgent outcome
DECISIONS:
- one confirmed decision per line, or None
ACTION_ITEMS:
- Owner | Task | Deadline | Pending | recipient email(s) or Unknown
KEY_DATES:
- YYYY-MM-DD | Event and any important time, or None
RISKS:
- one concrete risk/blocker per line, or None
UNRESOLVED:
- one question or unconfirmed commitment per line, or None
MISSING_INFORMATION:
- one missing detail that needs confirmation per line, or None

ACTION EXTRACTION RULES:
1. Capture all concrete tasks, not just sentences that start with a person's name. Include implied follow-ups such as assigning an owner, checking a portal closing time, confirming who uploads, creating a backup plan, reviewing quality, and submitting a deliverable.
2. One action per line. Split compound work into separate actions when they have different owners, deadlines, or completion criteria. Avoid duplicates; group tightly related quality checks when they share one owner/deadline. Make sure to include each separately mentioned deliverable and quality check; do not omit formatting, PDF/export, editable copy, latest-slide/chart updates, verification, backup plans, final review, or portal submission when present.
3. Owner means the person explicitly responsible for THAT task in the notes. A person's name attached to one task does not make them owner of other tasks. If notes say 'ask Rahul or Anu' about who will upload, the upload owner is Unassigned; create a task to ask Rahul or Anu and confirm. If notes say 'Anu to confirm?' or 'maybe Anu', use 'Anu (suggested; confirm)' only for the conclusion-confirmation task. Never assign the final report upload, formatting, or general review to Rahul, Anu, or Priya unless the notes explicitly assign it. If nobody is assigned, use Unassigned. Do not infer or fabricate email addresses from names; use Unknown unless the complete address literally appears in the source notes.
4. Keep status as Pending unless the notes clearly say the task is completed or in progress. Almost done is not completed: make the task finish and verify and keep it Pending unless explicitly stated as currently in progress.
5. Resolve relative dates using the supplied meeting date when present; otherwise use today's date in India. Use YYYY-MM-DD first, followed by the time/qualifier only when that time is explicitly linked to that action, e.g. 2026-10-19 — by 13:00, 2026-10-19 — before 16:00, 2026-10-19 — around 17:00. NEVER copy a time from one person's task to unrelated tasks: a 1 PM expected chart delivery applies to the charts/results task only, not every task. A report-ready-by-4-PM deadline can apply to report assembly, formatting, QA, and final PDF tasks that must be finished before readiness, but do not turn it into 1 PM. Preserve around, maybe, expected, and other uncertainty; do not turn estimates into guarantees. If no reliable deadline exists, use Unknown, not Pending.
6. Distinguish the final deliverable deadline from review/meeting times. Report ready by 4 PM is not the same as team review around 5 PM. Submit today is a separate task and portal closing time remains unknown until checked. Never assign the chart delivery deadline of 1 PM to the conclusion, formatting, report export, final review, or upload tasks. Use before 16:00 for work explicitly needed to make the report ready by 4 PM; use around 17:00 only for the review. Keep portal closing time Unknown until checked.
7. Treat no extension, urgent, ASAP, before the deadline, don't wait until last minute, and equivalent wording as urgency/risk signals. Reflect them in RISKS and task wording without fabricating an exact time.
8. Extract dependencies and fallback actions. If a deliverable may be delayed, create a backup/verification task; preserve conditional language such as if charts don't arrive.
9. Each action must have exactly five pipe-separated fields in this order: owner | task | deadline | status | recipient emails. Preserve email addresses only if explicitly present and complete in the notes. Never complete a truncated email address or infer one from a person's name; if absent or malformed, use Unknown.
10. If a date is known but exact time is not, use the date alone and explain timing uncertainty in task text or unresolved list. Do not put Pending in the deadline field. CRITICAL: whenever the notes say a deliverable must be submitted 'today', 'TODAY', or 'by end of day', set that submission action's deadline to today's supplied India date (YYYY-MM-DD), even if the portal closing time is unknown. Unknown closing time does NOT mean unknown deadline date. For these notes, today is the date explicitly supplied in the user message/context; otherwise use the supplied current India date.
11. Put unconfirmed responsibilities, missing portal closing time, pending data verification, possible delayed inputs, and unclear final uploader in UNRESOLVED or MISSING_INFORMATION as appropriate. Include actions to resolve them when the notes explicitly request follow-up.
12. Keep output concise but complete. Do not use JSON, Markdown tables, code fences, or extra commentary.
`;

export default async function (req, res) {
  const notes = typeof req.body?.notes === "string" ? req.body.notes.trim() : "";
  if (!notes) return res.status(400).json({ error: "Please enter meeting notes." });
  if (notes.length > 30000) return res.status(413).json({ error: "Meeting notes must be under 30,000 characters." });

  let key;
  try {
    key = await config.get("QUALCOMM_API_KEY");
  } catch (error) {
    console.error("Qualcomm key is not configured yet.");
    return res.status(503).json({ error: "Qualcomm AI is not configured yet. Open MinuteMap project Setup and add your QUALCOMM_API_KEY." });
  }
  if (!key) return res.status(503).json({ error: "Qualcomm AI is not configured yet. Open MinuteMap project Setup and add your QUALCOMM_API_KEY." });

  try {
    const response = await fetch("https://aisuite.cirrascale.com/apis/v2/chat/completions", {
      method: "POST",
      headers: { Authorization: "Bearer " + key, "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        model: "Llama-3.1-8B",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: "Today's date in India is " + new Date(Date.now() + 330 * 60 * 1000).toISOString().slice(0, 10) + ". Use it to resolve relative deadlines only when the meeting date is not supplied. Analyze these meeting notes. Return the exact labelled plain-text format. Do not use tools, JSON, Markdown tables, or code fences.\n\n" + notes }
        ],
        stream: false,
        temperature: 0,
        max_tokens: 2400
      }),
      timeout_ms: 55000
    });

    if (!response.ok) {
      console.error("Qualcomm upstream status", response.status);
      return res.status(502).json({ error: "Qualcomm AI is temporarily unavailable. Please try again." });
    }
    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    let text = Array.isArray(content) ? content.map(p => typeof p === "string" ? p : (p?.text || "")).join("\n") : content;
    if (typeof text !== "string" || !text.trim()) return res.status(502).json({ error: "AI returned an empty analysis. Please try again." });

    // Never let the model invent or autocomplete recipient addresses.
    // Only preserve complete email addresses literally present in the original notes.
    const sourceLower = notes.toLowerCase();
    let inActions = false;
    text = text.split(/\r?\n/).map(line => {
      const heading = line.trim().toUpperCase();
      if (heading.startsWith("ACTION_ITEMS:")) { inActions = true; return line; }
      if (/^(KEY_DATES|RISKS|UNRESOLVED|MISSING_INFORMATION|DECISIONS|SUMMARY|TOPIC|MEETING_DATE):/.test(heading)) inActions = false;
      if (!inActions || !line.includes("|")) return line;
      const cells = line.split("|");
      if (cells.length < 5) return line;
      const emailField = cells.slice(4).join("|").trim();
      if (!emailField || /^unknown$/i.test(emailField)) { cells.splice(4); cells.push(" Unknown"); return cells.join("|"); }
      const addresses = emailField.split(/[,;\s]+/).filter(Boolean);
      const valid = addresses.length > 0 && addresses.every(address =>
        /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(address) && sourceLower.includes(address.toLowerCase())
      );
      if (!valid) { cells.splice(4); cells.push(" Unknown"); }
      return cells.join("|");
    }).join("\n");
    res.json({ raw: text });
  } catch (error) {
    console.error("Qualcomm analysis failed", String(error?.message || error));
    res.status(502).json({ error: "Could not reach Qualcomm AI. Check the connection and try again." });
  }
}