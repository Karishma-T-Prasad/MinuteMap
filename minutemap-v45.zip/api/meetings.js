import { db } from "hatchable";

export const access = "user";
export const methods = ["GET", "POST"];

function parseDate(value) {
  const s = String(value || "").trim();
  const match = s.match(/^(\d{4}-\d{2}-\d{2})(?:\b|\s|—|–)/);
  if (!match) return null;
  const day = match[1];
  const d = new Date(day + "T00:00:00Z");
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === day ? day : null;
}
function list(value) { return Array.isArray(value) ? value : []; }
function str(value, max = 4000) { return typeof value === "string" ? value.trim().slice(0, max) : ""; }

export default async function (req, res) {
  const userId = req.user.id;
  if (req.method === "GET") {
    const { rows } = await db.query(
      "SELECT m.id, m.meeting_date, m.topic, m.summary, m.created_at, (SELECT count(*)::int FROM action_items a WHERE a.meeting_id = m.id) AS action_count FROM meetings m WHERE m.user_id = $1 ORDER BY m.created_at DESC LIMIT 50",
      [userId]
    );
    return res.json({ meetings: rows });
  }

  const body = req.body || {};
  const result = body.result || {};
  const rawNotes = str(body.raw_notes, 30000);
  if (!rawNotes || !str(result.topic, 300)) return res.status(400).json({ error: "Meeting notes and analysis are required." });
  const meetingDate = parseDate(result.meeting_date);
  const defaultEmails = [...new Set(str(body.default_email, 2000).replace(/\\r?\\n/g, ",").split(/[,;]+/).map(x => x.trim().toLowerCase()).filter(Boolean))];
  const defaultEmail = defaultEmails.join(", ");
  if (defaultEmails.some(address => !address.includes("@") || address.startsWith("@") || address.endsWith("@") || !address.split("@")[1].includes("."))) return res.status(400).json({ error: "Enter valid default reminder email addresses separated by commas or new lines." });
  const requestedDays = Number(body.default_reminder_days);
  const defaultReminderDays = Number.isInteger(requestedDays) ? Math.min(30, Math.max(0, requestedDays)) : 1;
  const actions = list(result.action_items).slice(0, 100);

  const inserted = await db.query(
    "INSERT INTO meetings (user_id, meeting_date, topic, summary, raw_notes, decisions, key_dates, risks, unresolved, missing_information) VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8::jsonb, $9::jsonb, $10::jsonb) RETURNING id",
    [userId, meetingDate, str(result.topic, 300) || "Untitled meeting", str(result.summary, 6000), rawNotes, JSON.stringify(list(result.decisions)), JSON.stringify(list(result.key_dates)), JSON.stringify(list(result.risks)), JSON.stringify(list(result.unresolved)), JSON.stringify(list(result.missing_information))]
  );
  const meetingId = inserted.rows[0].id;

  for (const item of actions) {
    const task = str(item?.task, 1500);
    if (!task) continue;
    const owner = str(item?.owner, 200);
    const ownerEmail = str(item?.owner_email, 2000).toLowerCase() || defaultEmail;
    const deadlineText = str(item?.deadline, 120);
    const deadline = parseDate(deadlineText);
    const rawStatus = str(item?.status, 40).toLowerCase();
    const status = rawStatus.includes("progress") ? "In Progress" : rawStatus === "done" || rawStatus === "completed" ? "Done" : "Pending";
    const itemDays = Number(item?.reminder_days_before);
    const reminderDays = Number.isInteger(itemDays) ? Math.min(30, Math.max(0, itemDays)) : defaultReminderDays;
    await db.query(
      "INSERT INTO action_items (meeting_id, user_id, owner, owner_email, task, deadline, deadline_text, status, reminder_days_before) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)",
      [meetingId, userId, owner, ownerEmail, task, deadline, deadlineText, status, reminderDays]
    );
  }
  res.status(201).json({ id: meetingId, saved: true, action_count: actions.filter(a => str(a?.task, 1500)).length });
}