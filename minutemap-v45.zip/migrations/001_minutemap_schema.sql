CREATE TABLE meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  meeting_date DATE,
  topic TEXT NOT NULL DEFAULT '',
  summary TEXT NOT NULL DEFAULT '',
  raw_notes TEXT NOT NULL,
  decisions JSONB NOT NULL DEFAULT '[]'::jsonb,
  key_dates JSONB NOT NULL DEFAULT '[]'::jsonb,
  risks JSONB NOT NULL DEFAULT '[]'::jsonb,
  unresolved JSONB NOT NULL DEFAULT '[]'::jsonb,
  missing_information JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE action_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  owner TEXT NOT NULL DEFAULT '',
  owner_email TEXT NOT NULL DEFAULT '',
  task TEXT NOT NULL,
  deadline DATE,
  deadline_text TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'Done')),
  reminder_enabled BOOLEAN NOT NULL DEFAULT true,
  reminder_days_before INTEGER NOT NULL DEFAULT 1 CHECK (reminder_days_before BETWEEN 0 AND 30),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reminder_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action_id UUID NOT NULL REFERENCES action_items(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  reminder_for_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'processing' CHECK (status IN ('processing', 'sent', 'failed')),
  sent_at TIMESTAMPTZ,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (action_id, reminder_for_date)
);

CREATE INDEX meetings_user_created_idx ON meetings (user_id, created_at DESC);
CREATE INDEX actions_user_deadline_idx ON action_items (user_id, deadline);
CREATE INDEX actions_meeting_idx ON action_items (meeting_id);
CREATE INDEX reminders_user_status_idx ON reminder_logs (user_id, status, created_at DESC);