CREATE TABLE notification_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  action_id UUID REFERENCES action_items(id) ON DELETE CASCADE,
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  notification_type TEXT NOT NULL CHECK (notification_type IN ('deadline_due_today', 'status_changed')),
  task TEXT NOT NULL,
  topic TEXT NOT NULL DEFAULT '',
  deadline DATE,
  old_status TEXT,
  new_status TEXT,
  recipient TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('sent', 'failed')),
  sent_at TIMESTAMPTZ,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX notification_logs_user_created_idx ON notification_logs (user_id, created_at DESC);
CREATE INDEX notification_logs_dedupe_idx ON notification_logs (user_id, notification_type, deadline, recipient, created_at DESC);