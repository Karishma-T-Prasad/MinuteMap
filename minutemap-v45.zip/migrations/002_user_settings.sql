CREATE TABLE user_settings (
  user_id TEXT PRIMARY KEY,
  reminder_email TEXT NOT NULL DEFAULT '',
  default_reminder_days INTEGER NOT NULL DEFAULT 1 CHECK (default_reminder_days BETWEEN 0 AND 30),
  reminders_enabled BOOLEAN NOT NULL DEFAULT true,
  last_test_email_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);